/**
*
* @file xsg_bwselector_hw.h
*
* This header file contains identifiers and driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
*/ 
#define XSG_BWSELECTOR_S_AXI_DECIMATION 0x0/**< s_axi_decimation */
